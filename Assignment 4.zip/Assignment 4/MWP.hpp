#include <vector>
#include <string>

#ifndef MWP_HPP
#define MWP_HPP


namespace mwp {
	int randBetween(int, int);
	void cls();
	std::vector<std::string> splitString(std::string,char);
}


#endif // !MWP_HPP
